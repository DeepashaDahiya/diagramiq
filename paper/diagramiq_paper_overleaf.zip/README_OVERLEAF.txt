DiagramIQ — Springer LNCS Research Paper Source Bundle
======================================================

How to view & compile this paper on Overleaf:
1. Go to https://www.overleaf.com and log in.
2. Click "New Project" -> "Upload Project".
3. Select this zip file ("diagramiq_paper_overleaf.zip").
4. Once loaded, ensure "main.tex" is selected as the main document.
5. Click "Recompile" (or Ctrl+S / Cmd+S).
6. The formatted camera-ready PDF will appear in the right-hand preview panel.

Authors: Deepasha, [Faculty Advisor / Mentor]
Title: DiagramIQ: A Neuro-Symbolic Multimodal Reasoning System for Structured Software Design Diagram Interpretation in Computing Education
